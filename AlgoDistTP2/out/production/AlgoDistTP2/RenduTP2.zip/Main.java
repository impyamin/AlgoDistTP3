

import jbotsim.Topology;
import jbotsim.ui.JViewer;

public class Main {
    public static void main(String[] args) {
        Topology tp = new Topology();
        tp.setDefaultNodeModel(PPNodeCounting2.class);
        tp.setClockSpeed(100);
        new PPScheduler(tp);
        new JViewer(tp);
    }
}